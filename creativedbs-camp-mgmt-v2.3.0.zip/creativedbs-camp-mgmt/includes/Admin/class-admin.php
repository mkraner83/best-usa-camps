<?php
/**
 * Admin area controller (safe placeholder).
 *
 * @package CreativeDBS\CampMgmt
 */
namespace CreativeDBS\CampMgmt\Admin;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Admin {
    public function __construct() {
        // Intentionally no hooks in this safe build.
    }
}
