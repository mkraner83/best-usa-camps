<?php
/**
 * Simple Camps List - Server-side rendering only
 */
namespace CreativeDBS\CampMgmt\PublicArea;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Camps_List {
	
	public function __construct() {
		add_shortcode( 'camps_list', [ $this, 'render' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_styles' ] );
	}
	
	public function enqueue_styles() {
		global $post;
		
		if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'camps_list' ) ) {
			wp_enqueue_style(
				'camps-list',
				plugin_dir_url( CREATIVE_DBS_CAMPMGMT_FILE ) . 'assets/camps-list.css',
				[],
				CDBS_CAMP_VERSION
			);
		}
	}
	
	public function render( $atts ) {
		$atts = shortcode_atts( [
			'columns' => '3',
		], $atts );
		
		global $wpdb;
		
		// Get search query
		$search_query = isset( $_GET['camp_search'] ) ? sanitize_text_field( $_GET['camp_search'] ) : '';
		
		// Build WHERE clause
		$where = "WHERE approved = 1";
		$prepare_args = [];
		
		if ( ! empty( $search_query ) ) {
			$like = '%' . $wpdb->esc_like( $search_query ) . '%';
			$where .= " AND (
				camp_name LIKE %s OR
				city LIKE %s OR
				state LIKE %s OR
				zip LIKE %s OR
				address LIKE %s OR
				about_camp LIKE %s OR
				activities LIKE %s OR
				camp_directors LIKE %s OR
				email LIKE %s OR
				phone LIKE %s OR
				website LIKE %s
			)";
			$prepare_args = array_fill( 0, 11, $like );
		}
		
		// Get approved camps with all needed fields
		$query = "SELECT id, camp_name, city, state, logo, opening_day, closing_day, minprice_2026, maxprice_2026
			FROM {$wpdb->prefix}camp_management 
			{$where}
			ORDER BY camp_name ASC";
		
		if ( ! empty( $prepare_args ) ) {
			$camps = $wpdb->get_results( $wpdb->prepare( $query, $prepare_args ), ARRAY_A );
		} else {
			$camps = $wpdb->get_results( $query, ARRAY_A );
		}
		
		if ( empty( $camps ) ) {
			return '<div class="camps-empty">
				<p>No camps available at this time.</p>
			</div>';
		}
		
		// Enrich camps with taxonomy data and camp page URL
		foreach ( $camps as &$camp ) {
			// Get camp types
			$camp['camp_types'] = $wpdb->get_col( $wpdb->prepare(
				"SELECT t.name FROM {$wpdb->prefix}camp_type_terms t
				INNER JOIN {$wpdb->prefix}camp_management_types_map m ON t.id = m.type_id
				WHERE m.camp_id = %d",
				$camp['id']
			) );
			
			// Get weeks
			$camp['weeks'] = $wpdb->get_col( $wpdb->prepare(
				"SELECT t.name FROM {$wpdb->prefix}camp_week_terms t
				INNER JOIN {$wpdb->prefix}camp_management_weeks_map m ON t.id = m.week_id
				WHERE m.camp_id = %d",
				$camp['id']
			) );
			
			// Get activities (first 4 only)
			$camp['activities'] = $wpdb->get_col( $wpdb->prepare(
				"SELECT t.name FROM {$wpdb->prefix}camp_activity_terms t
				INNER JOIN {$wpdb->prefix}camp_management_activities_map m ON t.id = m.activity_id
				WHERE m.camp_id = %d
				LIMIT 4",
				$camp['id']
			) );
			
			// Get camp page URL from credentials table (options)
			$camp_page_url = get_option( 'camp_page_url_' . $camp['id'], '' );
			$camp['page_url'] = ! empty( $camp_page_url ) ? $camp_page_url : '#';
		}
		
		$columns = intval( $atts['columns'] );
		if ( $columns < 2 || $columns > 4 ) {
			$columns = 3;
		}
		
		ob_start();
		?>
		<div class="camps-list">
			<div class="camps-header">
				<h2>Summer Camps Directory</h2>
				<p class="camps-count"><?php echo count( $camps ); ?> camps available</p>
			</div>
			
			<!-- Search Bar -->
			<div class="camps-search-bar">
				<form method="get" action="" class="camps-search-form">
					<?php
					// Preserve existing query parameters
					foreach ( $_GET as $key => $value ) {
						if ( $key !== 'camp_search' ) {
							echo '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
						}
					}
					?>
					<input 
						type="text" 
						name="camp_search" 
						class="camps-search-input" 
						placeholder="Search camps by name, location, activities..." 
						value="<?php echo esc_attr( $search_query ); ?>"
					>
					<button type="submit" class="camps-search-btn">Search</button>
					<?php if ( ! empty( $search_query ) ) : ?>
						<a href="<?php echo esc_url( remove_query_arg( 'camp_search' ) ); ?>" class="camps-reset-btn">Reset</a>
					<?php endif; ?>
				</form>
			</div>
			
			<div class="camps-grid camps-grid-<?php echo $columns; ?>">
				<?php foreach ( $camps as $camp ) : ?>
					<div class="camp-card">
						<?php if ( ! empty( $camp['logo'] ) ) : ?>
							<div class="camp-logo-circle">
								<img src="<?php echo esc_url( $camp['logo'] ); ?>" 
								     alt="<?php echo esc_attr( $camp['camp_name'] ); ?>">
							</div>
						<?php else : ?>
							<div class="camp-logo-circle camp-logo-placeholder">
								<span><?php echo esc_html( substr( $camp['camp_name'], 0, 1 ) ); ?></span>
							</div>
						<?php endif; ?>
						
						<div class="camp-info">
							<h3 class="camp-name"><?php echo esc_html( $camp['camp_name'] ); ?></h3>
							
							<?php if ( $camp['city'] || $camp['state'] ) : ?>
								<p class="camp-location">
									<?php 
									$location = array_filter( [ $camp['city'], $camp['state'] ] );
									echo esc_html( implode( ', ', $location ) );
									?>
								</p>
							<?php endif; ?>
							
							<?php if ( ! empty( $camp['camp_types'] ) ) : ?>
								<div class="camp-meta-row">
									<span class="meta-label">Camp Types:</span>
									<div class="camp-badges">
										<?php foreach ( $camp['camp_types'] as $type ) : ?>
											<span class="camp-badge"><?php echo esc_html( $type ); ?></span>
										<?php endforeach; ?>
									</div>
								</div>
							<?php endif; ?>
							
							<?php if ( ! empty( $camp['weeks'] ) ) : ?>
								<div class="camp-meta-row">
									<span class="meta-label">Weeks:</span>
									<div class="camp-badges">
										<?php foreach ( $camp['weeks'] as $week ) : ?>
											<span class="camp-badge"><?php echo esc_html( $week ); ?></span>
										<?php endforeach; ?>
									</div>
								</div>
							<?php endif; ?>
							
							<?php if ( ! empty( $camp['activities'] ) ) : ?>
								<div class="camp-meta-row">
									<span class="meta-label">Activities:</span>
									<div class="camp-badges">
										<?php foreach ( $camp['activities'] as $activity ) : ?>
											<span class="camp-badge"><?php echo esc_html( $activity ); ?></span>
										<?php endforeach; ?>
									</div>
								</div>
							<?php endif; ?>
							
							<div class="camp-dates-prices">
								<?php if ( $camp['opening_day'] ) : ?>
									<div class="camp-detail">
										<strong>Opening Day:</strong> <?php echo esc_html( date( 'M j, Y', strtotime( $camp['opening_day'] ) ) ); ?>
									</div>
								<?php endif; ?>
								
								<?php if ( $camp['closing_day'] ) : ?>
									<div class="camp-detail">
										<strong>Closing Day:</strong> <?php echo esc_html( date( 'M j, Y', strtotime( $camp['closing_day'] ) ) ); ?>
									</div>
								<?php endif; ?>
								
								<?php if ( $camp['minprice_2026'] ) : ?>
									<div class="camp-detail">
										<strong>Lowest Rate:</strong> $<?php echo esc_html( number_format( $camp['minprice_2026'], 2 ) ); ?>
									</div>
								<?php endif; ?>
								
								<?php if ( $camp['maxprice_2026'] ) : ?>
									<div class="camp-detail">
										<strong>Highest Rate:</strong> $<?php echo esc_html( number_format( $camp['maxprice_2026'], 2 ) ); ?>
									</div>
								<?php endif; ?>
							</div>
							
							<a href="<?php echo esc_url( $camp['page_url'] ); ?>" class="camp-visit-btn">
								Visit Camp Page
							</a>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
}

// Initialize
new Camps_List();
