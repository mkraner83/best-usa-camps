<?php
/**
 * Public/front-end controller.
 *
 * @package CreativeDBS\CampMgmt
 */
namespace CreativeDBS\CampMgmt\PublicArea;

defined( 'ABSPATH' ) || exit;

class Public_Controller {
	public function __construct() {
		// Front-end hooks will be added here incrementally.
	}
}
